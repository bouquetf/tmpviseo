<?php

namespace PHPSTORM_META
{
    $STATIC_METHOD_TYPES = array(
        \Piwik\Container\StaticContainer::get('') => [
            "" == "@",
        ],
    );
}
